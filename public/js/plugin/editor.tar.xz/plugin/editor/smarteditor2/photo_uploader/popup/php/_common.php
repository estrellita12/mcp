<?php
$dir = "../../../../../..";
include_once("$dir/common.php");
?>